@javax.xml.bind.annotation.XmlSchema(namespace = "http://unitybankng.com/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.etz.app3d.bankservices.unity.accountquery.ws;
